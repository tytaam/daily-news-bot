# ☀️ Daily News Bot — Setup Guide
### (Written simply — no tech experience needed!)

---

## What This Does
Every morning at **6:00 AM PST**, this bot will:
1. Search the internet for today's top news
2. Simplify it so it's easy to understand
3. Send it straight to your **Telegram** phone app

---

## Step 1 — Get Your Telegram Bot Token (5 min)

1. Open Telegram on your phone
2. Search for **@BotFather** and open it
3. Type `/newbot` and hit send
4. It'll ask for a name — type something like `My Morning News`
5. It'll ask for a username — type something like `mynews2025_bot`
6. BotFather will give you a **token** that looks like: `7123456789:AAFxyz...`
7. **Save that token** — you'll need it in Step 3

---

## Step 2 — Get Your Telegram Chat ID (2 min)

1. In Telegram, search for **@userinfobot**
2. Press Start or type `/start`
3. It will show your **Chat ID** — a number like `123456789`
4. **Save that number** — you'll need it in Step 3

---

## Step 3 — Get Your Anthropic API Key (5 min)

1. Go to **https://console.anthropic.com**
2. Sign up or log in
3. Click **API Keys** in the left menu
4. Click **Create Key**, name it "News Bot"
5. Copy the key (starts with `sk-ant-...`)
6. **Save it** — you'll need it next

---

## Step 4 — Deploy on Railway (Free Hosting, 10 min)

Railway lets your bot run 24/7 in the cloud for free.

1. Go to **https://railway.app** and sign up (use GitHub login)
2. Click **New Project → Deploy from GitHub repo**
3. Upload this project folder to a GitHub repo first:
   - Go to **https://github.com/new**
   - Create a new repo called `daily-news-bot`
   - Upload all the files from this folder
4. Back on Railway, select your repo
5. Railway will detect it's a Python project automatically

**Add your secret keys on Railway:**
1. In your Railway project, click **Variables**
2. Add these one by one:
   - `ANTHROPIC_API_KEY` = your key from Step 3
   - `TELEGRAM_BOT_TOKEN` = your token from Step 1
   - `TELEGRAM_CHAT_ID` = your chat ID from Step 2
3. Click **Deploy**

---

## Step 5 — Test It Right Now

Before waiting for 6am, test it immediately:

If running locally:
```bash
pip install -r requirements.txt
python test_now.py
```

You should get a message on Telegram within 30 seconds!

---

## How to Change the Time

Open `bot.py` and find this line:
```python
scheduler.add_job(..., trigger=CronTrigger(hour=6, minute=0, timezone=pst))
```

Change `hour=6` to whatever hour you want (0-23, where 0 = midnight, 12 = noon, 18 = 6pm).

---

## Troubleshooting

| Problem | Fix |
|---------|-----|
| No message received | Double-check your TELEGRAM_CHAT_ID — make sure you messaged the bot first |
| "Unauthorized" error | Your bot token is wrong — re-copy it from BotFather |
| News is empty | Your Anthropic API key might be wrong or have no credits |
| Bot stops working | Railway free tier may have limits — check your usage dashboard |

---

## Files in This Project

| File | What it does |
|------|-------------|
| `bot.py` | The main bot — runs the scheduler and sends news |
| `test_now.py` | Sends news RIGHT NOW for testing |
| `requirements.txt` | List of Python packages needed |
| `.env.example` | Template for your secret keys |
| `README.md` | This guide |

---

*Built with Claude AI + python-telegram-bot + APScheduler*
